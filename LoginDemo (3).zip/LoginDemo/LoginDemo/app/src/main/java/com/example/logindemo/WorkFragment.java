package com.example.logindemo;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class WorkFragment extends Fragment {
    private Button button;
    TextView result;
    EditText StartTime, EndTime;
    Button Bereken;

    double ResultNum;
    int num1,num2;

    TextView textView;
    TextView StartTime2;
    TextView EndTime2;
    TextView AntwTijd;
    Date StartDate;
    Date EndDate;
    Date Result;
    Button BtnTijd;
    int hour,min;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_work,container, false);
        button =(Button) view.findViewById(R.id.button);
        StartTime2=view.findViewById(R.id.startTime);
        EndTime2=view.findViewById(R.id.endTime);
        BtnTijd=view.findViewById(R.id.btnTijd);
        AntwTijd=view.findViewById(R.id.antwTijd);
        Calendar mCurrentTime = Calendar.getInstance();
        hour = mCurrentTime.get(Calendar.HOUR_OF_DAY);
        min = mCurrentTime.get(Calendar.MINUTE);
        EndTime2.setOnClickListener(view1 -> showTime(hour,min,view1));
        StartTime2.setOnClickListener(view1 -> showTime(hour,min, view1));
        BtnTijd.setOnClickListener(view1 -> {
            TimeZone tz=Calendar.getInstance().getTimeZone();
            long diff= EndDate.getTime()-StartDate.getTime();
            ResultNum= (double) diff / 3600000;
            diff-=tz.getOffset(diff);
            Date result=new Date(diff);
            SimpleDateFormat sdf=new SimpleDateFormat("HH"+"\n"+"mm");
            AntwTijd.setText(sdf.format(result));
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), CalculatorActivity.class);
                intent.putExtra("some_key", ResultNum);
                startActivity(intent);
            }
        });
        if(savedInstanceState!=null)
        {
            BtnTijd.setEnabled(savedInstanceState.getBoolean(STATE_BUTTON_ENABLED,false));
            StartDate = new Date(savedInstanceState.getLong(STATE_START_DATE));
            EndDate = new Date(savedInstanceState.getLong(STATE_END_DATE));
            AntwTijd.setText(savedInstanceState.getString(STATE_VERSCHIL, ""));
        }




        /*result=(TextView) view.findViewById(R.id.txtUur);
        StartTime=(EditText) view.findViewById(R.id.StartTime);
        EndTime=(EditText) view.findViewById(R.id.EndTime);
        Bereken=(Button) view.findViewById(R.id.btnCalc);


        Bereken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                num1=Integer.parseInt(StartTime.getText().toString());
                num2=Integer.parseInt(EndTime.getText().toString());
                if(num1>24||num2>24){
                    result.setText("max waarde is 24");
                }
                else if(num2>num1){

                    ResultNum=num2-num1;
                    result.setText(String.valueOf(ResultNum)+" uur");
                }
                else if(num2<num1){
                    result.setText("Eindwaarde kan niet kleiner zijn dan startwaarde!");
                }
                else if(num2==num1){
                    result.setText("0 uur");
                }

            }
        });*/
        return view;
    }
    void showTime(int hours,  int minte, View view) {
        TextView textView;
        if(view instanceof TextView){
            textView=(TextView) view;
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(requireActivity(), new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {

                    hour = selectedHour;
                    min = selectedMinute;
                    Calendar newTime=Calendar.getInstance();
                    newTime.set(Calendar.SECOND,0);
                    newTime.set(Calendar.MILLISECOND,0);
                    newTime.set(Calendar.HOUR_OF_DAY,selectedHour);
                    newTime.set(Calendar.MINUTE,selectedMinute);
                    SimpleDateFormat sdf=new SimpleDateFormat("HH:mm");
                    textView.setText(sdf.format(newTime.getTime()));
                    if(textView.getId()==R.id.startTime){
                        StartDate=newTime.getTime();
                    }
                    else{
                        EndDate=newTime.getTime();
                    }
                    if(EndDate!=null&&StartDate!=null){

                        BtnTijd.setEnabled(EndDate.getTime()>StartDate.getTime());
                    }

                }
            }, hours, minte, false);//Yes 24 hour time
            mTimePicker.setTitle("Select Time");
            mTimePicker.show();
        }

    }
    static final String  STATE_BUTTON_ENABLED= "buttonEnabled";
    static final String  STATE_START_DATE= "startDate";
    static final String  STATE_END_DATE= "endDate";
    static final String  STATE_VERSCHIL= "tijdVerschil";
    Button btnBereken;
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        if(StartDate!=null){
            savedInstanceState.putLong(STATE_START_DATE, StartDate.getTime());
        }
        if(EndDate!=null){
            savedInstanceState.putLong(STATE_END_DATE, EndDate.getTime());
        }
        if(result!=null){
            savedInstanceState.putString(STATE_VERSCHIL,AntwTijd.getText().toString());
        }

        savedInstanceState.putBoolean(STATE_BUTTON_ENABLED,BtnTijd.isEnabled());
        super.onSaveInstanceState(savedInstanceState);
    }
}
