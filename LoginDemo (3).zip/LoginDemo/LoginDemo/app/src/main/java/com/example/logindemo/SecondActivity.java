package com.example.logindemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;

public class SecondActivity extends AppCompatActivity {
    static final String STATE_CURRENT_FRAGMENT = "currentFragment";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);


        BottomNavigationView bottomNav= findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);
        if (savedInstanceState != null) {
            String tag = savedInstanceState.getString(STATE_CURRENT_FRAGMENT);

            Fragment myFragment = (Fragment)getSupportFragmentManager().findFragmentByTag(tag);
            if (myFragment != null ) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,myFragment).commit();
            }
        } else {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment(),"home").commit();
        }

    }
    public Fragment getVisibleFragment(){
        FragmentManager fragmentManager = SecondActivity.this.getSupportFragmentManager();
        List<Fragment> fragments = fragmentManager.getFragments();
        if(fragments != null){
            for(Fragment fragment : fragments){
                if(fragment != null && fragment.isVisible())
                    return fragment;
            }
        }
        return null;
    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        Fragment fragment= getVisibleFragment();
        if(fragment !=null){
            Log.i("LoginDemo",fragment.getTag());
            savedInstanceState.putString(STATE_CURRENT_FRAGMENT,fragment.getTag());
        }
        super.onSaveInstanceState(savedInstanceState);
    }

    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        String tag = savedInstanceState.getString(STATE_CURRENT_FRAGMENT);
        Fragment myFragment = (Fragment)getSupportFragmentManager().findFragmentByTag(tag);
        if (myFragment != null ) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,myFragment).commit();
        }


        //getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,selectedFragment).commit();
    }


    private  BottomNavigationView.OnNavigationItemSelectedListener navListener= new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment selectedFragment=null;
            String TAG="home";

            switch (item.getItemId()){
                    case R.id.nav_home:
                    selectedFragment=new HomeFragment();
                    TAG="home";
                    break;
                    case R.id.nav_work:
                    selectedFragment=new WorkFragment();
                    TAG="work";
                    break;
                    case R.id.nav_info:
                    selectedFragment=new InfoFragment();
                    TAG="info";
                    break;

            }
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,selectedFragment,TAG).commit();
            return true;
        }
    };

}